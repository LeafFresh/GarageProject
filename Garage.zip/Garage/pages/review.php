<?php

if(isset($_POST['submits'])) {
    $title = $_POST['reviewtitle'];
    $text = $_POST['reviewtext'];
    sendReview($dbh, $title, $text);
}

require_once('header.php ');
?>


<form for='review' method="post" class="review">
<h2><label for="reviewtitle">Schrijf een recensie of neem contact met ons op</label></h2><br>
<h3><input type="text" name="reviewtitle" placeholder="Title"><br>
<!-- <input type="text" name="reviewtext" placeholder="text"><br> -->
<textarea type="" name="reviewtext" placeholder="Place your text here" rows="4" cols="50"></textarea> <br>
<button type="submit" name="submits" class="submit">Send Message</button></h3>
</form>