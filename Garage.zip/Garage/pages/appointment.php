<?php 

getdata();

if(isset($_POST['submit'])) {
    $date = $_POST['Afspraak'];
    $type = $_POST['type'];
    makeAppointment($dbh, $date, $type);
}

require_once('header.php ');
?>

<img src="images/GTAcustoms.webp" class="LosSantoStatus">
<form action="" method="post" enctype="multipart/form-data">
<div class="calendar2">
    
    <div class="calendarText">
    Kies een datum:<br> <br>
    <label for="Afspraak">Afspraak:</label>
    <input type="date" id="Afspraak" name="Afspraak" value="2022-07-22"> 
    </div>
   
   
</div>

<div class="itemA">
    <label for="TypeAfspraak">Choose a appointment type:</label>

    <select name="type" id="TypeAfspraak">
        <option value="APK">APK</option>
        <option value="Controle">Controle</option>
        <option value="Reparatie">Reparatie</option>
        <option value="Lak">Lak</option>
    </select>
    <p class="itemText"> Text type voor uitleg afspraak type</p>
</div>
<button class="submitAfspraak" name="submit">Maak Afspraak</button>
</form>

<?php

?>