<?php 


require_once('header.php ');
?>


<img src="images/GTAcustoms.webp" class="LosSantoStatus">
<img src="./images/Wheel.png" class="wheel" width="50%" height="90%">
<div class="calendar">
    
    <div class="calendarText">
    Je ingeplande afspraak:<br> <br>
    <label for="Afspraak">Afspraak:</label>
    <input type="date" id="Afspraak" name="Afspraak" value="2022-07-22"> 
    </div>
    <p class="noAppointment">Je hebt nog geen afsrpaak in gepland, plan nu een afspraak. <br> <button class="afspraakM"> Afspraak maken</button></p>
   
</div>

<div class="status">

    <p class="statusText">Je status van je auto is: Onbekend</p>
</div>


<!--  -->