<?php

//db functie
require_once('var.php');

function getDbConnection() {

    try {
        $dbh =new PDO('mysql:host='.HOST.';charset=utf8;dbname='.DBNAME, USER, PASS);
        $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    catch(Execption $e) {
        echo 'Caught Execption: ', $e->getMessage(), "\n";
    }

    return $dbh;

}




// LOGIN AND REGISTER FUCNTIONS 

function checkLogin($dbh, $mail, $passwd) {
    try {
        $query = $dbh->prepare("SELECT *
                                FROM klant
                                WHERE mail = :mail");
        $query->bindParam(':mail', $mail, PDO::PARAM_STR);
        $query->execute();
        
        if($row = $query->fetch(PDO::FETCH_ASSOC)) {
            $_SESSION['id'] = $row['idklant'];
            $_SESSION['name'] = $row['voornaam'];
            if(password_verify($passwd, $row['wachtwoord'])){
                return TRUE;
                 $_SESSION['user'] = $row['mail'];
                 
            }
        }
        return FALSE;
        $incorrect = "Email or Password is inncorrect";
        echo $incorrect; // put text at the bottom of the form
    }
    catch (Execption $e) {
        echo "Caught execption: ", $e->getMessage(), "\n";
    }
    
}

 function register() {
    $dbh = getDbConnection(); 
    $name =$_POST['name'];   
    $email =$_POST['mail'];  
    $passwd =$_POST['passwd'];  
    $hash = password_hash($passwd, PASSWORD_DEFAULT);

    $sql ="INSERT INTO klant (voornaam, mail, wachtwoord)
            VALUES (:name, :email, :passwd)";

    $query = $dbh->prepare($sql);
    
    $query->bindParam(':name', $name, PDO::PARAM_STR);
    $query->bindParam(':email', $email, PDO::PARAM_STR);
    $query->bindParam(':passwd', $hash, PDO::PARAM_STR);

    $query->execute();

 }
// inserting into the car table so we can edit the care on our profile page
 function makecar() {
    $dbh = getDbConnection(); 
    $user = $_SESSION['id'];
    // $select1 =" SELECT *
    //             FROM klant
    //             WHERE idklant = $user";
    $select2 =" SELECT *
                FROM voertuig
                WHERE idklant = $user";
    $result = $dbh->query($select2);
    if ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        if ($row['idklant'] === $user) {
           
            return TRUE;
        } 
            
    } else {
        $dbh = getDbConnection(); 
    
        $makecar = "INSERT INTO voertuig (idklant)
                    VALUES ('$user')";
        $querycar = $dbh->prepare($makecar);
        $querycar->execute();
 }
}
// We need this data later in other functions, so we can easily call on this data
function getdata() {
    $dbh = getDbConnection(); 
    $klantid = $_SESSION['id'];
    $klant = "SELECT * FROM voertuig WHERE idklant = $klantid";
    
    $klantquery = $dbh->query($klant);
    if ($row = $klantquery->fetch(PDO::FETCH_ASSOC)) {
        $_SESSION['carid'] = $row['carID'];
        $_SESSION['plate'] = $row['kenteken'];
        $_SESSION['chassis'] = $row['chassisnummer'];
        $_SESSION['brand'] = $row['merk'];
    }
}
function sessionuser() {
    echo '<div class="alert alert-success" role="alert">';
    echo "<h2><img src='images/cloudcity.png' width='70px' height='45px'> Welcome, $_SESSION[user] To Los Santos Customs!</h2>";
    echo '</div>';
}

function logout() {
    if(isset($_POST['logout'])) {
        $_SESSION['user'] = 0;
        session_destroy();
        echo "<meta http-equiv='refresh' content='0'>";
    }
}

// SITE FUNCTIONALITY
function makeAppointment($dbh, $date, $type) {

    $dbh = getDbConnection(); 
    //if (isset($_POST['submit'])) {  
        
        
        $user = $_SESSION['user'];
        $idcar = $_SESSION['carid'];
        // $plate = $_SESSION['plate'];
        // $brand = $_SESSION['brand'];
        $appointment = "  INSERT INTO afspraak(begindatum, einddatum, naam, aantal_uren, idmonteur, idvoertuig, type_afspraak, status)
                    VALUES('$date', '','$user', '4', '1','$idcar', '$type', 'Aangevraagd')";
        $dbh->exec($appointment);

        echo "<meta http-equiv='refresh' content='0'>";
    //}
}


    function updateprofile($dbh, $name, $lastname, $mail, $brand, $chassis, $platenumber) {
        $dbh = getDbConnection(); 
        $user = $_SESSION['id'];
        $update = "UPDATE klant
                    SET voornaam = '$name', achternaam = '$lastname', mail = '$mail'
                    WHERE idklant = $user"; //
        $update2 = "UPDATE voertuig
                    SET merk = '$brand', chassisnummer ='$chassis', kenteken ='$platenumber'
                    WHERE idklant = $user";
        $dbh->exec($update);
        $dbh->exec($update2);

    }
// we need this to print the users information in the form, so we can change it without changing weird things
    function printprofile() {
        $dbh = getDbConnection(); 
        $user = $_SESSION['id'];
        $query = "  SELECT idklant, voornaam, achternaam, mail 
                    FROM klant 
                    WHERE idklant = $user";
        $query2 = "SELECT chassisnummer, merk, kenteken, idklant
                    FROM voertuig
                    WHERE idklant = $user";
        $result1 = $dbh->query($query);
        $result2 = $dbh->query($query);
        $result3 = $dbh->query($query);
        $result4 = $dbh->query($query2);
        $result5 = $dbh->query($query2);
        $result6 = $dbh->query($query2);
        
            ?>
            <form class="profileform" method='post'>
                <div class="firsthalf">
                    <label for="name">Naam</label><br>
                    <input type="text" name="name" value="<?php while ($row = $result1->fetch(PDO::FETCH_ASSOC)) { echo $row['voornaam']; } ?>"> <br>
                    <label for="lastname">Achternaam</label><br>
                    <input type="text" name="lastname" value="<?php while ($row = $result2->fetch(PDO::FETCH_ASSOC)) { echo $row['achternaam']; } ?>"> <br>
                    <label for="Email">Email</label><br>
                    <input type="text" name="mail" value="<?php while ($row = $result3->fetch(PDO::FETCH_ASSOC)) { echo $row['mail']; } ?>"> <br>
                </div><?php
            
            ?>
                <div class="secondhalf">
                    <label for="brand">Auto merk</label><br>
                    <input type="text" name="brand" value="<?php while ($row = $result4->fetch(PDO::FETCH_ASSOC)) { echo $row['merk']; } ?>"> <br>
                    <label for="chassis">Chassisnummer</label><br>
                    <input type="number" name="chassis" value="<?php while ($row = $result5->fetch(PDO::FETCH_ASSOC)) { echo $row['chassisnummer']; } ?>"> <br>
                    <label for="plate">Kenteken</label><br>
                    <input type="text" name="plate" value="<?php  while ($row = $result6->fetch(PDO::FETCH_ASSOC)) { echo $row['kenteken']; } ?>"> <br>
                    <button type="submit" name="submitA">Update profile</button>
                </div>
            </form>


            <?php
    }
    function sendReview($dbh,$title,$text) {
         
        $user = $_SESSION['id'];
        $review = "  INSERT INTO recensie(opmerking, idlogin, titel)
                    VALUES('$text', '$user', '$title')";
        $dbh->exec($review);
        echo "<meta http-equiv='refresh' content='0'>";
        echo "Your Review has been send";
    }
    

?>
