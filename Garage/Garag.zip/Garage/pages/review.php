<?php


require_once('header.php');
?>


<form for='review'>
<input type="text" name="reviewtext" placeholder="Place your text here">

</form>