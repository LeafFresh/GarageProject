<?php 

//variables
    define("HOST", "localhost");
    define("USER", "root");
    define("PASS", "");
    define("DBNAME", "garage")

?>